# PR 設計：移除靜音 pass + 強化錯誤日誌

> 設計日期：2026-03-17
> 狀態：待審核

---

## 一、現況分析

### 1.1 問題位置（已驗證）

| 檔案 | 數量 | 問題 |
|------|------|------|
| `translation_actions.py` | 10 | 靜音 pass |
| `extractor_actions.py` | 3 | 靜音 pass |
| `cache_history_store.py` | 4 | 靜音 continue/pass |
| `cache_query_panel.py` | 2 | 靜音 pass |
| `cache_shard_panel.py` | 1 | 靜音 pass |

### 1.2 問題說明

OpenClaw 建議：
- PR 的 `except:` → `except Exception:` 已正確修正 ✅
- 但「錯誤被悄悄吞掉」的問題還在
- 需移除靜音 pass
- 補上明確 logging
- 讓失敗可被觀測、可被追查

---

## 二、修復清單

### 2.1 translation_actions.py

| 行號 | 現況 | 修復 |
|------|------|------|
| 28-29 | `except Exception: pass` | 加入 log_warning |
| 40-41 | `except Exception: pass` | 加入 log_error |
| 65-66 | `except Exception: pass` | 加入 log_warning |
| 77-78 | `except Exception: pass` | 加入 log_error |
| 102-103 | `except Exception: pass` | 加入 log_warning |
| 114-115 | `except Exception: pass` | 加入 log_error |
| 132-133 | `except Exception: continue` | 可接受（輪詢邏輯） |
| 136-137 | `except Exception: view.progress.value = 0` | 可接受（預設值） |
| 142-143 | `except Exception: pass` | 加入 log_warning |

### 2.2 extractor_actions.py

| 行號 | 現況 | 修復 |
|------|------|------|
| 26-27 | `except Exception: pass` | 加入 log_warning |
| 144-145 | `except Exception: report_name = ...` | 可接受（設定預設值） |
| 234-235 | `except Exception: pass` | 加入 log_warning |
| 244-245 | `except Exception: pass` | 加入 log_warning |

### 2.3 cache_history_store.py

| 行號 | 現況 | 修復 |
|------|------|------|
| 54-55 | `except Exception:` → 設定預設值 | 加入 log_warning |
| 99-100 | `except Exception:` → arr = [] | 加入 log_warning |
| 118-119 | `except Exception: continue` | 可接受（解析邏輯） |
| 126-127 | `except Exception: continue` | 可接受（解析邏輯） |

### 2.4 cache_query_panel.py

| 行號 | 現況 | 修復 |
|------|------|------|
| 545-546 | `except Exception: p = 1` | 可接受（預設值） |
| 555-556 | `except Exception:` → 設定預設值 | 可接受（預設值） |

### 2.5 cache_shard_panel.py

| 行號 | 現況 | 修復 |
|------|------|------|
| 388-389 | `except Exception: return None` | 加入 log_warning |

---

## 三、實作檢查清單

### Phase 1: translation_actions.py ✅ 已完成
- [x] 行 28-29：加入 log_warning
- [x] 行 40-41：加入 log_error
- [x] 行 65-66：加入 log_warning
- [x] 行 77-78：加入 log_error
- [x] 行 102-103：加入 log_warning
- [x] 行 114-115：加入 log_error
- [x] 行 142-143：加入 log_warning

### Phase 2: extractor_actions.py ✅ 已完成
- [x] 行 26-27：加入 log_warning
- [x] 行 234-235：加入 log_warning
- [x] 行 244-245：加入 log_warning

### Phase 3: cache_history_store.py ✅ 已完成
- [x] 行 54-55：加入 log_warning
- [x] 行 99-100：加入 log_warning

### Phase 4: cache_shard_panel.py ✅ 已完成
- [x] 行 388-389：加入 log_warning

### Phase 5: 驗證
- [x] 執行 `python -m py_compile` 語法檢查

---

## 四、Validation checklist

- [ ] **錯誤可觀測**：
  - [ ] 所有 silent pass 都已移除或補上 logging
  - [ ] 例外情況有明确 log_warning 或 log_error

- [ ] **功能正確**：
  - [ ] 翻譯服務執行正常
  - [ ] 提取服務執行正常
  - [ ] Cache 歷史記錄正常

- [ ] **無回歸**：
  - [ ] 現有測試通過

---

## 五、風險評估

| 風險 | 等級 | 緩解措施 |
|------|------|----------|
| Log 過多 | 低 | 只在關鍵路徑加 log |
| 效能影響 | 低 | logging 代價極小 |
| 行為改變 | 低 | 只加 log，不改邏輯 |
